<?php
    session_start();
    // Set session variables
    $_SESSION["current_username"] = "LOGIN";
    $_SESSION["current_usertype"];
?>