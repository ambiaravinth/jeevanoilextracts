<?php
include_once 'db.php';
$display = mysqli_query($conn,"select * from workdata");
?>